﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso3
{
    public class Azafata
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string CUIL { get; set; }

        public Tripulacion Tripulacion;
    }
}
