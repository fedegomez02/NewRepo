﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso3
{
    public class Tripulacion
    {
        public string Nombre { get; set; }
        public string Aerolinea { get; set; }
        public List<Azafata> Azafatas { get; set; }
    }
}
