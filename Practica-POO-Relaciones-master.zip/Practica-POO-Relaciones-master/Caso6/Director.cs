﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso6
{
    public class Director
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string PostGrado { get; set; }
        public Clinica Clinica { get; set; }
    }
}
