﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caso2
{
    public class Cliente
    {
        public string Nombre { get; set; }
        public string Apelldio { get; set; }
        public int IdCliente { get; set; }
        public List<Pedido> Pedidos { get; set; }
    }
}
