﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Caso1
{
    public class Cliente
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public Usuario Usuario { get; set; }
    }
}
